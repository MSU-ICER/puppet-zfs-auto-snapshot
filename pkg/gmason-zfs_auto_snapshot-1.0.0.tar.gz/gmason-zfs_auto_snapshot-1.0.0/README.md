puppet-zfs-auto-snapshot
========================

# Installation
Install via Puppet Forge: `puppet module install gmason-zfs_auto_snapshot`
# Configuration
Currently configuration is done by directly manipulating `zfs_auto_snapshot::cron`, but a subclass for configuration is on the way
